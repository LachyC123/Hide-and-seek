# FALSE SAFE — project notes for Claude

Read this before touching anything. It carries the decisions that aren't obvious from the code.

## What this is

A real-world location game. Players physically run and hide outdoors; their phones supply the
map, roles, zone, votes and catches. Three factions: **hiders** (survive), **seekers** (catch
everyone; every catch converts that player into another seeker), and one hidden **imposter**
who looks exactly like a hider and wins alone by being the last uncaught hider.

Family-legible is the top design rule: every screen must tell a player what happened, what it
means, and what to do now, inside about five seconds. Strategic depth comes from what players
do to each other, never from operating the app.

## Layout

```
src/shell.html   markup + all CSS. Contains one empty <script>\n</script> block.
src/game.js      the entire game, one IIFE.
build.js         inlines game.js into shell.html -> index.html. No bundler, no deps.
index.html       BUILT ARTIFACT — never edit by hand, it is overwritten.
test/harness.js  124 pure-logic tests, no DOM. Runs in ~1s.
test/smoke*.js   6 jsdom runs that boot the real built file and drive the UI.
```

`src/game.js` is split by comment banners:

- `CORE_START` … `CORE_END` — **pure logic, no DOM, no globals from the runtime.** Geo maths,
  role assignment, zone generation, catching, voting, win conditions, missions, GPS filtering,
  tile maths, OSM parsing, preview scale maths. The harness extracts this block by its markers
  and runs it in a `vm` sandbox. If you rename or remove the markers, the whole test suite dies.
- PART 2 — runtime state, audio, procedural characters, storage/room sync helpers
- PART 3 — host simulation, bots, networking, location
- PART 4 — map rendering
- PART 5 — screens, HUD, alerts, dev tools, boot
- PART 6 — street data, settings preview

## Rules for changing things

1. **Never edit `index.html`.** Edit `src/`, then `npm run build`.
2. **Keep CORE pure.** No `document`, no `window`, no `G`. If a function needs game state,
   pass it in. This is what makes the logic testable, and the tests are the only thing that
   will tell a future session it broke a rule it never read about.
3. **Any logic change needs a harness test**, in the same style: one behaviour per test, named
   as a sentence a person would say. `npm test` before you call anything done.
4. Vanilla ES5-flavoured JS, `var`, no frameworks, no build tooling beyond `build.js`. It has
   to stay one file that works from a static host.
5. **No `localStorage` / `sessionStorage`.** Persistence goes through `window.storage` when
   present, and every call is wrapped so the game still runs when it isn't.
6. Prefer adding to the DEV panel over adding temporary debug UI. It already covers every
   phase jump, forced win, catch, vote and zone move.

## Invariants the tests protect

Break any of these and the game stops making sense:

- The next zone is always fully contained in the current one, but its centre is **offset**, not
  concentric. Camping the original middle must never be a strategy.
- Imposter victory fires the moment the last genuine hider is caught, **before** any seeker win
  and before the clock. Seekers catching everyone can hand the imposter the win. That's intended.
- An exposed imposter (correctly voted out) loses the solo win condition and their powers, but
  stays in the game as an ordinary hider and can win with the hiders.
- Nobody is ever eliminated. Caught players convert to seekers after a grace period so they
  can't be chain-caught.
- Hiders see no other players. Seekers see other seekers, plus hiders only during FULL SIGNAL
  or a sustained zone violation. The imposter gets no omniscience.
- Blips are approximate and tighten over the match; they never pin a hider exactly.
- Catch validation requires fresh location on both sides, correct roles, and the GPS allowance.

## Current state

Working: profile and 12 procedural characters, room-code lobby, roles, scatter, real-street map,
smooth character movement, seeker blips, catching and conversion, moving/shrinking zone with
preview, imposter missions and anonymous tips, scheduled tribunals, full signal, all three win
conditions, results, host-tunable rules with a live scale preview, GPS filtering, diagnostics,
solo mode with bots, full dev panel.

Known limits, in the order they'll hurt:

1. **Multiplayer transport is host-authoritative over shared key-value storage with ~2.6s
   polling.** The host must stay open, and state is readable, so roles are only hidden by
   client-side convention. Real fix: Supabase (rooms + players tables, RLS so a client can only
   read what its role permits, Realtime for push, one Edge Function running `hostSim` server
   side). The CORE block ports across almost unchanged — that's why it's kept pure.
2. Street data comes from public Overpass. Fine for testing, one fetch per play area, cached to
   the device. Self-host or move to a paid vector source before any real release.
3. Characters are drawn procedurally in `drawChar`. The call signature is sprite-sheet shaped,
   so swapping in real sheets is one function.
4. Objectives are two types (jammer, intel). Imposter missions are two types (follow, lure).

## Commands

```
npm install        once, for jsdom
npm run build      src -> index.html
npm test           124 core tests + 6 smoke runs
npm run serve      localhost:8080 — geolocation works on localhost, unlike file://
```

Deploying: push to `main`. The Pages workflow builds, runs the full suite, and only deploys if
everything passes. GPS and street data need https, which Pages gives you.
